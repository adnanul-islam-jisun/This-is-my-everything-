#include<iostream>
using namespace std;


int main(){

    int siz ;
    cout<< " Enter Size:";
    cin>>siz;
    int array[siz];
    cout<< " Enter array value:";
    for(int i = 0;i<siz;i++){
        cin>>array[i];
    }
    int target ;
    cout<<"Target:";
    cin>>target;
    int sum =0;
    int count11= 0;
    int forI ;
    int forJ ;
    int first ;
    int sec;
    for(int i = 0;i<siz;i++){
       first =array[i];
         forI = i;
         if(array[i]< target){
           for(int j=1 ;i<siz;j++){

               sec =  array[j];
            sum = first+sec;
            if(sum == target){
                forJ = j;
                count11 = 1;
                break;
            }
         }
         }
         if(count11 == 1){
            break;
         }
    }
    if(count11 == 1){
     cout<< forI << " "<< forJ;
    }

    else cout<< "Invalid";
    return 0;
}
