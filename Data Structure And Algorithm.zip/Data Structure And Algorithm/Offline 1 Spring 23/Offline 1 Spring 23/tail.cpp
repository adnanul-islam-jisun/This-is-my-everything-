#include <iostream>

using namespace std;3


#define NULL_VALUE -99999
#define SUCCESS_VALUE 99999


class ListNode
{

public:
    int item;
    ListNode* next;
};


class LinkedListWithTail
{

    ListNode* head;
    ListNode* tail;  /*EXTRA*/
    int length;

public:

    LinkedListWithTail()
    {
        head = NULL;
        tail=NULL; // initially set to NULL
        length = 0;
    }

    int getLength() const
    {
        return length;
    }

    void insertItem(int element)
    {
        length++;
        ListNode *New=new ListNode();    //New named node declared with size of node declared before
        New->item=element;       //inserts the new element to the value part of node New
        New->next=NULL;
        if(head==NULL)           //makes the next part of node New NULL so that no garbage value remains
        {
            New->next=head;           //the address of previously first node, which was stored in head is now assigned to next part of node New
            head=New;                 //the address of new first element which is present in node New is assigned to head node
            tail=head;
        }
        else
        {
            New->next=head;           //the address of previously first node, which was stored in head is now assigned to next part of node New
            head=New;
        }

    }

    int deleteItem(int value)
    {
        ListNode* current = head;
        ListNode* prev =NULL;

        while (current != NULL)
        {
            if (current->item == value)
            {
                ListNode* temp = current;
                if (prev == NULL)
                {
                    head = current->next;
                    current = head;
                }
                else
                {
                    prev->next = current->next;
                    current = current->next;
                }
                delete temp;
                length--;
            }
            else
            {
                prev = current;
                current = current->next;
            }
        }

    }

    ListNode* searchItem(int item) const
    {
        ListNode* temp = head; // start at the beginning

        while(temp != NULL)
        {
            if(temp->item == item)
            {
                return temp;
            }

            temp = temp->next; // move to next node
        }

        return NULL; // Not found
    }

    void printList() const
    {
        ListNode* temp = head;

        while(temp != NULL)
        {
            printf("%d->", temp->item);
            temp = temp->next;
        }

        printf("\n");
        printf("Length: %d\n",getLength());
    }

    //------------write code for the functions below-----------
    int insertLast(int ele)
    {
        ListNode *New=new ListNode();   //New named node declared with size of node declared before
        New->item=ele;                                   //inserts the new element to the value part of node New
        New->next=NULL;
        tail->next=New;
        tail=tail->next;
        New=NULL;
        length++;
    }

    ListNode* getItemAt(int pos) const
     {
        if (pos < 1 || pos > length) {
        return NULL ;
    }

    ListNode* currentNode = head;
    int currentPosition = 1;
    while (currentPosition < pos) {
        currentNode = currentNode->next;
        currentPosition++;
    }

    return currentNode;
    }


    int deleteLast()
    {
        if(head==NULL)
        {
            printf("list is empty and nothing to delete\n");
        }

         ListNode * cur=head;
         ListNode * prev=NULL;
        while(cur->next!=NULL)
        {
            prev=cur;
            cur=cur->next;
        }

        if(prev->next!=NULL)
        {
            prev->next=NULL;
        }
        tail=prev;

        delete cur;
    }

    void swapNodes(int pos1, int pos2) {
    if (pos1 == pos2) {
        return;
    }


    ListNode* node1 = nullptr;
    ListNode* prev1 = nullptr;
    ListNode* node2 = nullptr;
    ListNode* prev2 = nullptr;

    ListNode* currentNode = head;
    int currentPosition = 1;
    while (currentNode != nullptr) {
        if (currentPosition == pos1) {
            node1 = currentNode;
        }
        else if (currentPosition == pos2) {
            node2 = currentNode;
        }

        if (node1 == nullptr) {
            prev1 = currentNode;
        }
        if (node2 == nullptr) {
            prev2 = currentNode;
        }

        currentNode = currentNode->next;
        currentPosition++;
    }

    if (node1 == nullptr || node2 == nullptr) {
        return;
    }
    if (prev1 != nullptr) {
        prev1->next = node2;
    }
    else {
        head = node2;
    }
    if (prev2 != nullptr) {
        prev2->next = node1;
    }
    else {
        head = node1;
    }
    ListNode* temp = node1->next;
    node1->next = node2->next;
    node2->next = temp;
}


    // Added
    ~LinkedListWithTail()
    {
        while(deleteLast() != NULL_VALUE)
        {
            /*NOTHING here*/
        }
    }
};

int main(void)
{
    LinkedListWithTail ll;
    int choice, item;

    while(1)
    {
        printf("1. Insert item (First)\n2. Inset item (Last)\n");
        printf("3. Delete item (Last)\n4. Delete item\n");
        printf("5. Search item\n6. Get item at\n7. Print list\n8.Swap position\n9. exit\n");

        printf("\nEnter choice: ");
        scanf("%d",&choice);

        if(choice == 1)
        {
            printf("\nEnter item: ");
            scanf("%d", &item);

            ll.insertItem(item);
        }
        else if(choice == 2)
        {
            printf("\nEnter item: ");
            scanf("%d", &item);

            ll.insertLast(item);
        }
        else if(choice == 3)
        {
            if(ll.deleteLast() == NULL_VALUE)
            {
                printf("\nDeletion failed\n");
            }
            else
            {
                printf("\nDeletion successful\n");
            }
        }
        else if(choice == 4)
        {
            printf("\nEnter item: ");
            scanf("%d", &item);

            if(ll.deleteItem(item) == NULL_VALUE)
            {
                printf("\nDeletion failed\n");
            }
            else
            {
                printf("\nDeletion successful\n");
            }
        }
        else if(choice == 5)
        {
            printf("\nEnter item: ");
            scanf("%d", &item);

            ListNode* returnNode = ll.searchItem(item);

            if(returnNode != NULL)
            {
                printf("\nItem found\n");
            }
            else
            {
                printf("\nItem not found\n");
            }
        }
        else if(choice == 6)
        {
            int position;

            printf("\nEnter position: ");
            scanf("%d", &position);

            ListNode* returnNode = ll.getItemAt(position);

            if(returnNode != NULL)
            {
                printf("\nItem found: %d\n", returnNode->item);
            }
            else
            {
                printf("\nItem not found\n");
            }
        }
        else if(choice == 7)
        {
            ll.printList();
        }
        else if(choice == 8)
        {
            int n1,n2;
            cout<<"Enyer 1st position:";
            cin>>n1;
            cout<<endl<<"Enter 2nd position:";
            cin>>n2;
            ll.swapNodes(n1,n2);
        }
        else if(choice == 9)
        {
            break;
        }
        else
        {
            printf("\nInvalid choice\n");
        }

        printf("\n---------------------------------------------\n\n");
    }

    return 0;
}
