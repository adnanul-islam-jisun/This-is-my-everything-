#include <stdio.h>
#include<iostream>
using namespace std;

 int part(int  arr[],int low,int high){
    int privot=arr[high];
    int i=low-1;
    for(int j=low;j<high;j++){
        if(arr[j]<privot){
            i++;
            swap(arr[i],arr[j]);
        }

    }
     i++;
        swap(arr[i],arr[high]);
        return i;

}


  void quickSort(int arr[],int low,int high){
     if(low<high){
            int p=part(arr,low,high);
            quickSort(arr,low,p-1);
            quickSort(arr,p+1,high);

     }
 }

int main()
{
    int arr[]={5,6,3,1,8,9};
    int low=0;
    int high=sizeof(arr)/sizeof(arr[0])-1;
    quickSort(arr,low,high);
    for(int i=0;i<sizeof(arr)/sizeof(arr[0]);i++){
        cout<< arr [i]<<" ";
    }
    return 0;
}
