#include<bits/stdc++.h>
using namespace std;

const int MAX = 100005;
vector<int> adj[MAX];
bool visited[MAX];

void bfs(int start) {
    queue<int> q;
    q.push(start);
    visited[start] = true;
    int level = 0;
    int NCL = 1;
    int NNL = 0;

    while (!q.empty()) {
        int v = q.front();
        q.pop();
        NCL--;

        for (int u : adj[v]) {
            if (!visited[u]) {
                visited[u] = true;
                q.push(u);
                NNL++;
            }
        }

        if (NCL == 0) {
            cout << "Number of nodes at level " << level << " is " << NNL << "\n";
            level++;
            NCL = NNL;
            NNL = 0;
        }
    }
}

int main() {
    int n, m;
    cin >> n >> m;
    int start;
    cin >> start;

    // n is the number of nodes and m is the number of edges
    for (int i = 0; i < m; i++) {
        int u, v;
        cin >> u >> v;
        adj[u].push_back(v);
        adj[v].push_back(u);
    }



    bfs(start);

    return 0;
}
