#include <iostream>
#include <cmath>
using namespace std;

int main() {
    int t;
    cin >> t;
    while (t--) {
        int n, x1, y1, x2, y2;
        cin >> n >> x1 >> y1 >> x2 >> y2;

        // determine ring number for start and end cells
        int r1 = min(min(x1-1, n-x1), min(y1-1, n-y1));
        int r2 = min(min(x2-1, n-x2), min(y2-1, n-y2));

        // compute minimum number of moves
        int dr = abs(r2-r1);
        int perim1 = 2*(n-2*r1);
        int perim2 = 2*(n-2*r2);
        int dc = abs((x2-x1)-(y2-y1));
        int moves = dr + min(perim1-dc, perim2-dc);

        cout << moves << endl;
    }
    return 0;
}
