#include <iostream>

using namespace std;
void CountSort(int arr[],int n){

    // Find the largest element of the array
    int m=arr[0];
    for(int i=0;i<n;i++){
        m=max(m,arr[i]);

    }

    int sz=m+1;
    int Count[sz]={0};

    // Store the count of each element
    for(int i=0;i<n;i++){
        Count[arr[i]]++;
    }
    // Store the cummulative count of each array

    for(int i=1;i<=m;i++){
        Count[i]+=Count[i-1];
    }
    // Find the index of each element of the original array in count array, and
  // place the elements in output array
    int last[n];
    for(int i=0;i<n;i++){
        last[--Count[arr[i]]]=arr[i];

    }
    for(int i=0;i<n;i++){
        arr[i]=last[i];
    }
}

int main()
{
    int arr[]={0,1,4,3,8,5,6,8,4,2,2,2,9};
    int n=sizeof(arr)/sizeof(arr[0]);
    CountSort(arr,n);
    for(int i=0;i<n;i++){
        cout<<arr[i]<<" ";
    }
    return 0;
}
