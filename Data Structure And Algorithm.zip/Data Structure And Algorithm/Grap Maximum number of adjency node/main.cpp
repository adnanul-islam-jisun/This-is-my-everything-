#include<iostream>
#include<vector>
using namespace std;

int main() {
    int v, e;
    cin >> v >> e;


    vector<vector<int>> adj_m(v, vector<int>(v, 0));
    for (int i = 0; i < e; i++) {
        int u, v;
        cin >> u >> v;
        adj_m[u][v] = 1;
        adj_m[v][u] = 1;
    }


    int max_d = -1, max_v = -1;
    for (int i = 0; i < v; i++) {
        int d = 0;
        for (int j = 0; j < v; j++) {
            if (adj_m[i][j] == 1) {
                d++;
            }
        }
        if (d > max_d) {
            max_d = d;
            max_v = i;
        }
    }

    cout << "Vertex " << max_v << " has the highest number of adjacent nodes (" << max_d << ")" << endl;

    return 0;
}
