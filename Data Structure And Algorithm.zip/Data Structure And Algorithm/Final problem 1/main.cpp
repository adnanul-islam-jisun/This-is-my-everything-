#include <iostream>

using namespace std;


struct Node {
    int data;
    Node* left;
    Node* right;
};


Node* newNode(int data) {
    Node* temp = new Node;
    temp->data = data;
    temp->left = temp->right = NULL;
    return temp;
}


Node* insert(Node* root, int data) {
    if (root == NULL) {
        return newNode(data);
    }
    if (data < root->data) {
        root->left = insert(root->left, data);
    } else if (data > root->data) {
        root->right = insert(root->right, data);
    }
    return root;
}


int Even(Node* root) {
    if (root == NULL) {
        return 0;
    }
    int sum = 0;
    if (root->data % 2 == 0) {
        sum += root->data;
    }
    sum += Even(root->left);
    sum += Even(root->right);
    return sum;
}

int main() {
    Node* root = NULL;

    root = insert(root, 8);
    insert(root, 2);
    insert(root, 10);
    insert(root, 1);
    insert(root, 6);
    insert(root, 14);
    insert(root, 4);
    insert(root, 7);
    insert(root, 13);

    cout << "Sum of even numbers in BST: " << Even(root) << endl;

    return 0;
}
