#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;

    while(t--)
    {
        int n, d;
        cin >> n >> d;
        int a[n+1];
        int k=n+1;
        for(int i==0; i<n; i++)
        {
            cin>>a[i];
        }
        int _max=0;
        for(int i=i; i>0; i--)
        {
            for(int j = n-1; j >= i; j--)
            {
                arr[j] = arr[j-1];
            }

            // insert the number at the insertion position
            arr[i] = d;
            int num=0;

            for(int i = 0; i < k; i++)
            {
                num = num * 10 + arr[i];
            }
            int _max=max(_max,num);


        }
        cout<<_max<<endl;



        return 0;
    }
