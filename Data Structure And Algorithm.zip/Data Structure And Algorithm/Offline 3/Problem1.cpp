
#include <iostream>
using namespace std;

class Queue {
private:
    int front;
    int rear;
    int arr[1000];

public:
    Queue() {
        front = -1;
        rear = -1;
        for (int i = 0; i < 1000; i++) {
            arr[i] = 0;
        }
    }

    bool isEmpty() {
        if (front == -1 && rear == -1) {
            return true;
        } else {
            return false;
        }
    }

    bool isFull() {
        if (rear == 999) {
            return true;
        } else {
            return false;
        }
    }

    void enqueue(int val) {
        if (isFull()) {
            cout << "Queue full" << endl;
            return;
        } else if (isEmpty()) {
            rear = 0;
            front = 0;
            arr[rear] = val;
        } else {
            rear++;
            arr[rear] = val;
        }
    }

    int dequeue() {
        int x = 0;
        if (isEmpty()) {
            cout << "Queue is Empty" << endl;
            return x;
        } else if (rear == front) {
            x = arr[rear];
            rear = -1;
            front = -1;
            return x;
        } else {
            x = arr[front];
            arr[front] = 0;
            front++;
            return x;
        }
    }

    int count() {
        return (rear - front + 1);
    }

    void display() {
        cout << "All values in the Queue are - " << endl;
        for (int i = 0; i < 1000; i++) {
            cout << arr[i] << "  ";
        }
    }
};

void sortQueue(Queue& A, Queue& B, Queue& C) {
    int n = A.count();

    for (int i = 0; i < n; i++) {

        int min = A.dequeue();
        while (!A.isEmpty()) {
            int val = A.dequeue();
            if (val < min) {
                B.enqueue(min);
                min = val;
            } else {
                B.enqueue(val);
            }
        }


        C.enqueue(min);


        while (!B.isEmpty()) {
            A.enqueue(B.dequeue());
        }
    }
}

int main() {
    Queue A, B, C;
    int n;
    cout << "Enter the number of elements: ";
    cin >> n;


    for (int i = 0; i < n; i++) {
        int num;
        cout << "Enter element " << i + 1 << ": ";
        cin >> num;
        A.enqueue(num);
    }


    sortQueue(A, B, C);


    cout << "\nSorted elements in Queue C are:" << endl;
    while (!C.isEmpty()) {
        cout << C.dequeue() << " ";
    }
    cout << "\nQueue A are:" << endl;
    //while (!A.isEmpty()) {
        cout << A.dequeue() << " ";
    //}
    cout << "\nQueue B are:" << endl;
   // while (!B.isEmpty()) {
        cout << B.dequeue() << " ";
    //}

    return 0;
}
