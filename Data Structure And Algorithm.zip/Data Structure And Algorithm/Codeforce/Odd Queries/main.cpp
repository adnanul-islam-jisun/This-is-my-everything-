#include <iostream>

using namespace std;

int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        int n,q;
        cin>>n>>q;
        int a[n];
        int b[n];
        for(int i=1; i<=n; i++)
        {
            cin>>a[i];
            b[i]=a[i];

        }
        int l,r,k;
        int sum;
        for(int i=1; i<=q; i++)
        {
            cin>>l>>r>>k;
            for(int i=l; i<=r; i++)
            {
                b[i]=k;
            }
            sum=0;
            for(int j=1; j<=n; j++)
            {
                sum+=b[j];

            }
            for(int i=1; i<=n; i++)
            {
                b[i]=a[i];

            }
            if(sum%2!=0)
                cout<<"YES"<<endl;
            else
                cout<<"NO"<<endl;
        }
    }
    return 0;
}
