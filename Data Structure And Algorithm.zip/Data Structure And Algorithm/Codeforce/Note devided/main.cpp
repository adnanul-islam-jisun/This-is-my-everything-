#include <iostream>
#include <cstring>

using namespace std;

const int MAX_N = 1000000;

void sieve(int n) {
    bool isPrime[MAX_N+1];
    memset(isPrime, true, sizeof(isPrime)); // Initialize all numbers as prime
    isPrime[0] = isPrime[1] = false; // 0 and 1 are not primes

    // Loop through all numbers from 2 to sqrt(n)
    for (int i = 2; i*i <= n; i++) {
        // If i is prime, mark all its multiples as not prime
        if (isPrime[i]) {
            for (int j = i*i; j <= n; j += i) {
                isPrime[j] = false;
            }
        }
    }


    for (int i = 2; i <= n; i++) {
        if (isPrime[i]) {
            cout << i << " ";
        }
    }
}

int main() {
    int n;
    cout << "Enter a number: ";
    cin >> n;

    cout << "Prime numbers up to " << n << " are: ";
    sieve(n);

    return 0;
}
