#include <iostream>
using namespace std;

void check(int a[], int j, int n) {
    if (j >= n) {
        return;
    }
    if (a[0] < a[j]) {
        a[0]++;
        a[j]--;
        check(a, j, n);
    }
    else if (a[0] > a[j]) {
        j++;
        check(a, j, n);
    }
    else {
        j++;
        check(a, j, n);
    }
}

int main() {
    int t;
    cin >> t;
    while (t--) {
        int n;
        cin >> n;
        int a[n];
        for (int i = 0; i < n; i++) {
            cin >> a[i];
        }
        check(a, 1, n);
        cout << a[0] << endl;
    }
    return 0;
}
