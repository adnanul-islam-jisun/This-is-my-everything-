#include <iostream>
#include <cstdlib>
#include <cmath>

using namespace std;


int main() {
    int t;
    cin>>t;
    while(t--){
        int n,x,p;
        cin>>n>>x>>p;
        int step=0;
        int i=0;
        while(p-i>=0){
            step+=p-i;
            i++;
            cout<<step;

        }
        if(0<=n-x-step){
            cout<<"YES"<<endl;

        }
        else
            cout<<"NO"<<endl;
    }
    return 0;
}
