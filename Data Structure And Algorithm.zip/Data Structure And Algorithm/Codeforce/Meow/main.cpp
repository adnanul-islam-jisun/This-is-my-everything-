#include <iostream>
#include <string>

using namespace std;

int main() {
    int t;
    cin >> t;
    while (t--) {
        int n;
        cin >> n;

        string s;
        getline(s,n);

        // Check for "meow" or variations of it
        bool found = false;
        int j = 0;
        for (int i = 0; i < n; i++) {
            if (s[i] == "meow"[j]) {
                j++;
                if (j == 4) {
                    found = true;
                    break;
                }
            }
        }

        // Output the result
        if (found) {
            cout << "Yes" << endl;
        } else {
            cout << "No" << endl;
        }
    }
    return 0;
}
