#include <iostream>
#include<algorithm>
#include <bits/stdc++.h>

using namespace std;

int main()
{

    int t;
    cin>>t;
    while(t--)
    {
        long int n;
        cin>>n;
        vector<long long int> a(n);
        for(int i=0; i<n; i++)
        {
            cin>>a[i];
        }
        long long int k=0;

        sort(a.begin(), a.end());

        while(a[0]>1)
        {
            a[0]--;
            k++;
        }


        for(long int i=1; i<n; i++)
        {
            while((a[i-1]+1)<a[i])
            {
                a[i]--;
                k++;
            }
        }

        cout<<k<<endl;

    }
    return 0;
}
