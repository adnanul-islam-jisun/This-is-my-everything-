#include <iostream>

using namespace std;

int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        int n,P=0,N=0;
        cin>>n;
        int a[n];
        for(int i=0; i<n; i++)
        {
            cin>>a[i];
            if(a[i]>0)
            {
                P++;
            }
            else if(a[i]<0)
            {
                N++;
            }
        }
        int j=P;
        for(int i=1; i<=n; i++)
        {
            if(i<=P)
            {
                cout<<i<<" ";
            }
            else
            {
                cout<<--P<<" ";
            }
        }
        cout<<endl;
        int k=1;
        for(int i=1; i<=n; i++)
        {
            if(N*2>=i)
            {
                if(i%2==0)
                    cout<<"0"<<" ";
                else
                    cout<<"1"<<" ";
            }

            else
            {
                cout<<k++<<" ";
            }
        }



    }
    return 0;
}
