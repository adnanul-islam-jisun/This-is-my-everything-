#include <iostream>
#include <string>
#include <algorithm>

using namespace std;

string sortString(string s)
{
    string lowercase = "";
    string uppercase = "";

    // separate lowercase and uppercase characters
    for (char c : s)
    {
        if (islower(c))
        {
            lowercase += c;
        }
        else if (isupper(c))
        {
            uppercase += c;
        }
    }

    // sort the lowercase and uppercase strings
    sort(lowercase.begin(), lowercase.end());
    sort(uppercase.begin(), uppercase.end());

    // combine the sorted strings
    string result = "";
    int i = 0;
    int j = 0;
    while (i < lowercase.length() && j < uppercase.length())
    {
        if(tolower(uppercase[j])==lowercase[i])
        {
            result += lowercase[i];
            result += uppercase[j];
            i++;
            j++;
        }
        else if(tolower(uppercase[j])>lowercase[i])
        {

            i++;

        }
        else if(tolower(uppercase[j])<lowercase[i])
        {

            j++;
        }
    }


    while (i < lowercase.length())
    {
        result += lowercase[i];
        i++;
    }

    while (j < uppercase.length())
    {
        result += uppercase[j];
        j++;
    }
    cout<<result;

    return result;
}

int countPairs(string s)
{
    int count = 0;
    for (int i = 0; i < s.length() - 1; i++)
    {
        if ((islower(s[i]) && isupper(s[i + 1])) &&(tolower(s[i])==tolower(s[i+1])) )
        {
            count++;
        }
    }
    return count;
}

int main()
{
    string s = "aAaaBACacbE";
    string sortedString = sortString(s);
    int pairCount = countPairs(sortedString);
    cout << "Sorted string: " << sortedString << endl;
    cout << "Pair count: " << pairCount << endl;
    return 0;
}
