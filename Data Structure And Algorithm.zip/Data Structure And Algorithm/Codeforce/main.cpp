#include <iostream>

using namespace std;
const int st=1e5;
int a[st];

int main()
{
    int t;;
    cin>>t;

    while(t--){
        int n,sum=0;
        cin>>n;

        for(int i=0;i<n;i++){
            cin>> a[i];
            sum+=a[i];
        }
        for(int i=0;i<n;i++){
            if(a[i]==a[i+1])
            {
              if(a[i]==1)
                    sum=sum-4;
              else
                sum=sum+4;
            }
            sum=sum;


        }
        cout<<sum;
    }
    return 0;
}
