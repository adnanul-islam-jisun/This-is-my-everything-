#include <iostream>

using namespace std;

int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        int n;
        cin>>n;
        int a[n];
        for(int i=0; i<n; i++)
        {
            cin>>a[i];
        }
        sort(a,a+n);
        int j=0;

        for(int i=0; i<n; i++)
        {
            if(a[i] != a[j])
            {
                j++;
                a[j] = a[i];
            }
        }


        arr[j+1];
        arr[0]=1;
        arr[1]=2;
        int sum=3;


        for(int i=2; i<j; i++)
        {
            arr[i]=sum;
            sum=sum+a[i-1];
            cout<<sum;



        }
    }

    return 0;
}
