#include <iostream>

using namespace std;

int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        int n;
        cin>>n;

        int a[n];
        int sum=0;
        for(int i=0; i<n; i++)
        {
            cin>> a[i];
            if(a[i]==0)
            {
                int j=0;
                int _max=0;
                while((i-j)>=0)
                {
                    if(a[i-j]>_max){
                        _max=a[i-j];
                    }
                    j++;
                    if(a[i-j]==0)
                        break;

                }
                sum=sum+_max;

            }
        }
        cout <<"Output:"<< sum;
    }
    return 0;
}
