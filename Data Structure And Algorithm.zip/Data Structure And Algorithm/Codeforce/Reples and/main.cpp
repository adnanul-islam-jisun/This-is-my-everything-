#include<iostream>
#include<string.h>
using namespace std;

int main(){

    int t;
    cin>>t;

    while(t!=0){
    int n;
    cin>>n;
    string s;
    cin >> s;
    for (int i = 0; i < n; i++) {
        if (s[i] == 'a') {
             s[i] = '0';
        } else{
            s[i] = '1';
        }
    }
    int co = 0;
    for(int i = 0;i<n;i++){

        if(s[i]== 1 &&s[i+1] == 1||s[i]==s[i+1]){
           co ++;
        }
        else if(s[i]!=s[i+1]){

        }
    }
    if(co != 0){
        cout<< "\"NO\"" <<endl;
    }
    else{
      cout<< "\"YES\"" <<endl;
    }
    cout<< s <<endl;
    t--;
    }



}
