#include<stdio.h>
int main(){
//1.TAKING input ways.

//3.TAKING input ways.
char s[]="nothing to say.";
int i=0,sum=0;
while(s[i]!='\0'){
        if(s[i]=='a'||s[i]=='e'||s[i]=='i'||s[i]=='o'||s[i]=='u'){
                sum++;
    printf("%c",s[i]);
        }
    i++;
}
printf("%d",sum);






}
