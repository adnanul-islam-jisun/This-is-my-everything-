
#include <iostream>

using namespace std;

struct node {
    int value;
    struct node* prev;
    struct node* next;
};

struct node* head = NULL;
struct node* tail = NULL;

void printReverse() {
    if(head == NULL) return;
    struct node* i;
    for(i = tail; i != NULL; i = i->prev) {
        printf("%d ", i->value);
    }
    printf("\n");
}

void deleteLast() {
    if(head == NULL) return;
    else if(head == tail) {
        free(tail);
        head = NULL;
        tail = NULL;
    }
    else {
        struct node* temp = tail;
        tail = tail->prev;
        tail->next = NULL;
        temp->prev = NULL;
        free(temp);
    }
}

void print() {
    if(head == NULL) {
        printf("Empty\n");
        return;
    }
    struct node* temp = head;
    while(temp != NULL) {
        printf("%d ", temp->value);
        temp = temp->next;
    }
    printf("\n");
}

struct node* linearSearch(int data) {
    struct node* i;
    for(i = head; i != NULL; i = i->next) {
        if(i->value == data) return i;
    }
    return NULL;
}

void insertBefore(int fEle, int data) {
    struct node* ptr = linearSearch(fEle);
    if(ptr == NULL) return;
    struct node* temp = (struct node*)malloc(sizeof(struct node));
    temp->next = NULL;
    temp->prev = NULL;
    temp->value = data;
    temp->prev = ptr->prev;
    ptr->prev->next = temp;
    ptr->prev = temp;
    temp->next = ptr;
    temp = NULL;
    ptr = NULL;
    return;
}



void insertFirst(int data) {
    struct node* temp = (struct node*)malloc(sizeof(struct node));
    temp->next = NULL;
    temp->prev = NULL;
    temp->value = data;
    if(head == NULL) {
        head = temp;
        tail = head;
    }
    else {
        temp->next = head;
        head->prev = temp;
        head = head->prev;
        temp = NULL;
    }
}

void LinkedList(int value) {
    struct node* temp = (struct node*)malloc(sizeof(struct node));
    temp->value = value;
    temp->next = NULL;
    temp->prev = NULL;
    if(head == NULL) {
        head = temp;
        tail = head;
    }
    else {
        tail->next = temp;
        temp->prev = tail;
        tail = tail->next;
        temp = NULL;
    }
}




  int main() {
    int ch, x, y;
    while(1) {
        printf("1.Print Reverseorder \n2.Insert Element \n3.Insert given element befor b \n4.Delete last \n5.Insert First \n6.Print \n7.Exit\n");
        scanf("%d", &ch);
        if(ch == 2) {
            printf("enter value:");
            scanf("%d", &x);
            LinkedList(x);
        } else if(ch == 1) {
            printReverse();
        } else if(ch == 3) {
            printf("Search element :");
            scanf("%d", &x);
            printf("Value :");
            scanf("%d", &y);
            insertBefore(x, y);
        } else if(ch == 4) {
            deleteLast();
        } else if(ch == 5) {
            printf("Insert Value :");
            scanf("%d", &x);
            insertFirst(x);
        } else if(ch == 6) {
            print();
        } else if(ch == 7) {
            return 0;
        } else {
            return 0;
        }
    }
    return 0;
}
