#include <Keypad.h>


const byte ROWS = 4;
const byte COLS = 3;

char keys[ROWS][COLS] = {
  {'1', '2', '3'},
  {'4', '5', '6'},
  {'7', '8', '9'},
  {'*', '0', '#'}
};

byte rowPins[ROWS] = {6, 5, 4, 3};
byte colPins[COLS] = {9, 8, 7};

Keypad keypad = Keypad(makeKeymap(keys), rowPins, colPins, ROWS, COLS);

// Pre-set pins
const char* correctPins[] = {"1234", "1235", "1236"};

void setup() {
  Serial.begin(9600);
   randomSeed(millis());
}

void loop() {
  char key = keypad.getKey();

  if (key != NO_KEY) {
    // If user presses '*', prompt for 4 digit pin
    if (key == '*') {
      char pin[5];
      int i = 0;

      while (i < 4) {
        char digit = keypad.getKey();

        if (digit >= '0' && digit <= '9') {
          Serial.print(digit);
          pin[i++] = digit;
        }
      }

      // Check if pin is correct
      bool isPinCorrect = false;

      for (int i = 0; i < sizeof(correctPins) / sizeof(*correctPins); i++) {
        if (strcmp(pin, correctPins[i]) == 0) {
          isPinCorrect = true;
          Serial.println("\nYour pin" + String(i + 1) + " is correct");
          break;
        }
      }

      if (!isPinCorrect) {
        Serial.println("\nIncorrect pin");
      }
    }

    // If user presses '#', prompt for 11 digit phone number
    if (key == '#') {
      char phoneNumber[12];
      int i = 0;

      while (i < 11) {
        char digit = keypad.getKey();

        if (digit >= '0' && digit <= '9') {
          Serial.print(digit);
          phoneNumber[i++] = digit;
        }
      }

      Serial.println("\nPhone number: " + String(phoneNumber));
    }

    // If user presses '0', prompt for new pin
    if (key == '0') {

      //Serial.println("\nEnter new 4 digit pin:");
      char newPin[5];
      int i = 0;
        Serial.println("\nWhich box to you want to change:");
      char c=keypad.waitForKey();
      Serial.print(c);
      Serial.println("\n");
      while (i < 4) {
         char digit ='0'+ random(0,10);
        delay(100);
        if (digit >= '0' && digit <= '9') {
          Serial.print(digit);
          newPin[i++] = digit;
        }
      }
      // Set new pin
      strcpy(correctPins[c-'1'], newPin);
      Serial.println("\nNew pin set to: " + String(correctPins[c-'1']));
    }
  }
}
