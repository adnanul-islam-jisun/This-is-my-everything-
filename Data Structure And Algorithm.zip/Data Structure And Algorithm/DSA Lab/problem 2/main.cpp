#include <iostream>

using namespace std;
void bubbleSort(float arr[], float size) {
    for(int i=0; i<size-1; i++) {
           for(int j=0; j<size-i-1; j++) {
               if(arr[j] > arr[j+1]) {
                   //swap
                   float temp = arr[j];
                   arr[j] = arr[j+1];
                   arr[j+1] = temp;
               }
           }
       }
}


int main()
{
    int n;
    cout<<"Input number of People";
    cin>>n;
    float hight[n];
    float weight[n];
    float BMI[n];
    cout<< "Input Hight"<<endl;
    for(int i=0;i<n;i++){
        cin>>hight[i];
    }
    cout<< "Input Weight"<<endl;
    for(int i=0;i<n;i++){
        cin>>weight[i];
    }
    for(int i=0;i<n;i++){
       BMI[i]=weight[i]/(hight[i]*hight[i]);
    }
    bubbleSort(BMI,n);

    for(int i=0;i<3;i++){
        cout<<BMI[i]<<" ";
    }



    return 0;
}
