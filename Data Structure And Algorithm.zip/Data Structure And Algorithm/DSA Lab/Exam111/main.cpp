#include <iostream>

using namespace std;
int  searche(int arr[],int s,int n){
    int i;
    for( i=0;i<n;i++){
        if(arr[i]==s){
            return i;
            cout <<"gdsh"<<i;
            break;
        }
    }
    cout<<"Not Found";
    return -1;
}

int main()
{
    int n,sum=0,j=0,m;
    cin>> n;
    int arr[n];

    cout<<"Input the array:"<<endl;

    for(int i=0;i<n;i++){
        cin>>arr[i];
    }
     cout<<"Which Number do you want?";
    cin>>m;

    int in=searche(arr,m,n);
     for(int i=0;i<4;i++){
         if((in+i)<=(n-1)){
        sum=sum+arr[in+i];
         }
         else if((in+i)>(n-1)){
            sum=sum+arr[j];
            j++;
         }
    }
    cout<<"Sum:"<<sum;

    return 0;
}
