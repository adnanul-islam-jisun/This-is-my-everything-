#include <iostream>

using namespace std;
 int binarySearch(int arr[], int l, int r, int x,int n)
{
    int y=0;
    while (l <= r) {
        int m = l + (r - l) / 2;

        // Check if x is present at mid
        if (arr[m] == x){
             for(int i=m;i<n;i++){
                if (arr[m] == x){
                    y++;
                }
            }
            return y-1;
        }

        // If x greater, ignore left half
         else if (arr[m] < x)
            l = m + 1;

        // If x is smaller, ignore right half
        else
            r = m - 1;
    }

    // if we reach here, then element was
    // not present

}

int main()
{
    int n,x;
    cin>>n;

    int arr[n];
    cout<<"Array"<<endl;
    for(int i=0;i<n;i++){
        cin>>arr[i];
    }
    cout<< "Item";
    cin>>x;
    int result = binarySearch(arr, 0, n - 1, x,n);
    cout<<result;


}
