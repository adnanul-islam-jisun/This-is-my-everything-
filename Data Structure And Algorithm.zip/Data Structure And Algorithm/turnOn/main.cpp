#include <iostream>
#include <string>

using namespace std;

int minOperationsToTurnOnAllBulbs(string s) {
    int count = 0;
    char lastColor = ' ';
    for (int i = 0; i < s.size(); i++) {
        if (s[i] != lastColor) {
            count++;
            lastColor = s[i];
        }
    }
    if (count % 2 == 0) {
        return count / 2;
    } else {
        return -1; // It's impossible to turn on all bulbs
    }
}

int main() {
    string s;
    cin >> s;
    int minOps = minOperationsToTurnOnAllBulbs(s);
    if (minOps == -1) {
        cout << "It's impossible to turn on all bulbs" << endl;
    } else {
        cout << "Minimum number of operations to turn on all bulbs: " << minOps << endl;
    }
    return 0;
}
