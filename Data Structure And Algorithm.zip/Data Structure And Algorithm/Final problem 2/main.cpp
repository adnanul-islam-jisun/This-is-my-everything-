#include <iostream>
#include <vector>
#include <queue>

using namespace std;


bool bfs(vector<vector<int>>& graph, int p, int q)
{
    queue<int> q_nodes;
    vector<bool> visited(graph.size(), false);

    visited[p] = true;
    q_nodes.push(p);

    while (!q_nodes.empty())
    {
        int node = q_nodes.front();
        q_nodes.pop();

        if (node == q)
        {
            return true;
        }

        for (int neighbor : graph[node])
        {
            if (!visited[neighbor])
            {
                visited[neighbor] = true;
                q_nodes.push(neighbor);
            }
        }
    }

    return false;
}
bool dfs(vector<vector<int>>& graph, int p, int q )

{
    vector<bool> visited(graph.size(), false);


    visited[p] = true;

    if (p == q)
    {
        return true;
    }

    for (int neighbor : graph[p])
    {
        if (!visited[neighbor] && dfs(graph, neighbor, q))
        {
            return true;
        }
    }

    return false;
}


int main()
{
    int num_vertices, num_edges;
    cin >> num_vertices >> num_edges;

    vector<vector<int>> graph(num_vertices);

    for (int i = 0; i < num_edges; i++)
    {
        int u, v;
        cin >> u >> v;
        graph[u].push_back(v);
    }

    int p, q;
    cin >> p >> q;

    string s;
    cin>>s;
    bool path=false;
    if(s=="DFS")
         path=dfs(graph,p,q);
    else if(s=="BFS")
         path = bfs(graph, p, q);


    if (path)
    {
        cout << "true" << endl;
    }
    else
    {
        cout << "false" << endl;
    }

    return 0;
}
