#include <iostream>

using namespace std;



void MergeSort(int arr[],int Start,int mid ,int en){
    int newarr[en-Start+1];
    int a1=Start;
    int a2 =mid+1;
    int x=0;

    while(a1<=mid&&a2<=en){
        if(arr[a1]<=arr[a2]){
            newarr[x++]=arr[a1++];
        }
        else{
            newarr[x++]=arr[a2++];
        }
    }
    while(a1<=mid){
        newarr[x++]=arr[a1++];
    }
    while(a2<=en){
        newarr[x++]=arr[a2++];
    }
    for(int i=0,j=Start;i<sizeof(newarr)/sizeof(newarr[0]);i++,j++){
        arr[j]=newarr[i];
       // cout<< arr[i]<<" ";
    }


}
void devide(int arr[],int start,int en){
    if(start>=en){
        return;
    }
            int mid=(start+en)/2;
            devide(arr,start,mid);
            devide(arr,mid+1,en);

            MergeShort(arr,start,mid,en);

}

int main()
{
    int a[5]={5,4,8,9,1};
    int start=0;
    int en=sizeof(a)/sizeof(a[0])-1;

    devide(a,start,en);
    for(int i=0;i<sizeof(a)/sizeof(a[0]);i++){

        cout<< a[i]<<" ";
    }


    return 0;
}
