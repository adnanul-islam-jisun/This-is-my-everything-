#include <Keypad.h>
#include <Servo.h>
#include <Stepper.h>

#define SERVO_PIN 2
int doorservoPin = 4;

int pirPin = A4;







// Creates an instance of stepper class
// Pins entered in sequence IN1-IN3-IN2-IN4 for proper step sequence

const byte ROWS = 4;
const byte COLS = 3;
// Defines the number of steps per rotation
const int stepsPerRevolution = 2038;
Stepper myStepper = Stepper(stepsPerRevolution, 10, 12, 11, 13);



Servo miniServo;
Servo doorServo;

char keys[ROWS][COLS] =
{
    {'1', '2', '3'},
    {'4', '5', '6'},
    {'7', '8', '9'},
    {'*', '0', '#'}
};

byte rowPins[ROWS] = {A0, A1, A2, A3};
byte colPins[COLS] = {9, 8, 7};

Keypad keypad = Keypad(makeKeymap(keys), rowPins, colPins, ROWS, COLS);

// Pre-set pins
const char* correctPins[] = {"1231", "1232", "1233","1234","1235","1236"};

int servoPos = 0;
int motionDetected = 0;

void setup()
{
    Serial.begin(9600);
    miniServo.attach(SERVO_PIN);

    pinMode(pirPin, INPUT);
  doorServo.attach(doorservoPin);

    miniServo.write(90); // set servo to 90 degree position


    Serial.println("For print press 1\nFor Pen press 2\nFor Book press 3");
}






void loop()
{
    char key = keypad.getKey();

    if (key != NO_KEY)
    {
        // If user presses '*', prompt for 4 digit pin

        if (key == '1')
        {
            char pin[5];
            int i = 0;
            Serial.print("Input your PIN:");


            while (i < 4)
            {
                char digit = keypad.waitForKey();

                if (digit >= '0' && digit <= '9')
                {
                    Serial.print(digit);
                    pin[i++] = digit;
                }
            }

            // Check if pin is correct
            bool isPinCorrect = false;

            for (int i = 0; i < sizeof(correctPins) / sizeof(*correctPins); i++)
            {
                if (strstr(pin, correctPins[i]) != NULL)
                {
                    isPinCorrect = true;
                    Serial.println("\nYour pin " + String(i + 1) + " is correct");
                    if(i==0){
                      motor(2.2);
                    }
                    else if(i==1){
                      motor(3);
                    }
                     else if(i==2){
                      motor(4);
                    }
                    else if(i==3){
                      motor(5);
                    }
                    else if(i==4){
                      motor(6);
                    }
                    else if(i==5){
                      motor(7);
                    }
                    else if(i==6){
                      motor(8);
                    }
                    break;
                }
            }

            if (!isPinCorrect)
            {
                Serial.println("\nIncorrect pin");
            }
        }

        // If user presses '#', prompt for 11 digit phone number
        if (key == '2')
        {


            Serial.println("Motor");
            motor(2);

        }

        // If user presses '0', prompt for new pin
        if (key == '3')
        {
            //Input the Box number
            Serial.println("\nWhich box to you want to change:");
            char c=keypad.waitForKey();
            Serial.print(c);
            Serial.println("\n");


            //Generate the PIN

            char newPin[5];
            int i = 0;
            // Clear new pin array
            for (int i = 0; i < sizeof(newPin); i++)
            {
                newPin[i] = '\0';
            }

            while (i < 4)
            {
                randomSeed(millis());
                char digit ='0'+ random(0,10);
                delay(100);
                if (digit >= '0' && digit <= '9')
                {
                    Serial.print(digit);
                    newPin[i++] = digit;
                }
            }
            // Set new pin
            strcpy(correctPins[c-'1'], newPin);
            Serial.println("\nNew pin set to: " + String(correctPins[c-'1']));
            // Clear new pin array
            for (int i = 0; i < sizeof(newPin); i++)
            {
                newPin[i] = '\0';
            }

            //Input the phone number
            Serial.print("Input the phone number:");
            char phoneNumber[12];
            int j = 0;
            // Clear phonenumber  array
            for (int i = 0; i < sizeof(phoneNumber); i++)
            {
                phoneNumber[i] = '\0';
            }

            while (j < 11)
            {
                char digit = keypad.waitForKey();

                if (digit >= '0' && digit <= '9')
                {
                    Serial.print(digit);
                    phoneNumber[j++] = digit;
                }
            }
            Serial.println("\nPhone number: " + String(phoneNumber));


        }
        if (key == '4')
        {
            //Input the book code
            Serial.println("\nInput the book code:");
            char b=keypad.waitForKey();
            Serial.print(c);
            Serial.println("\n");
            if(k=='1'){
                bookmotor(1);
            }
            else if (k=='2'){
                bookmotor(2);
            }
            else if (k=='3'){
                bookmotor(3);
            }
            else if (k=='4'){
                bookmotor(4);
            }
            else if (k=='5'){
                bookmotor(5);
            }
            else if (k=='6'){
                bookmotor(6);
            }
            else{
                Serial.println("This book is not available");
            }




    }

     //Door Control

    motionDetected = analogRead(pirPin);

      if (motionDetected >600) {
        // Open the door
        for (int i = 0; i <= 180; i++) {
          doorServo.write(i);
          delay(15);
        }
        delay(2000);

        // Close the door
        for (int i = 180; i >= 0; i--) {
          doorServo.write(i);
          delay(15);
        }
      }

      delay(100);


}
//motor control function
void motor(float n)
{

      myStepper.setSpeed(10);
	myStepper.step(stepsPerRevolution*n);
	delay(1000);
     // set servo to 10 degree position
     for (int i = 90; i >= 20; i--) {
          miniServo.write(i);
          delay(15);
        }
    delay(2000);
    // set servo to 90 degree position
     for (int i = 20; i <= 90; i++) {
          miniServo.write(i);
          delay(15);
        }

	// Rotate CCW quickly at 10 RPM
	myStepper.setSpeed(10);
	myStepper.step(-stepsPerRevolution*n);
	delay(1000);
}
void bookmotor(float n){

      myStepper.setSpeed(10);
	myStepper.step(stepsPerRevolution*n);
	delay(1000);
     // set servo to 10 degree position
     for (int i = 90; i >= 180; i--) {
          miniServo.write(i);
          delay(15);
        }
    delay(2000);
    // set servo to 90 degree position
     for (int i = 180; i <= 90; i++) {
          miniServo.write(i);
          delay(15);
        }

	// Rotate CCW quickly at 10 RPM
	myStepper.setSpeed(10);
	myStepper.step(-stepsPerRevolution*n);
	delay(1000);

}





