#include <iostream>
using namespace std;

class CircularQueue
{
private:
    int Fr, rear;
    int Qsize;
    char *arr;

public:
    CircularQueue(int sz)
    {
        Fr = rear = -1;
        Qsize = sz;
        arr = new char[Qsize];
    }

    bool isFull()
    {
        return (rear + 1) % Qsize == Fr;
    }

    bool isEmpty()
    {
        return Fr == -1;
    }

    void enqueue(char data)
    {
        if (isFull())
        {
            cout << "Queue is full\n";
        }
        else
        {
            rear = (rear + 1) % Qsize;
            arr[rear] = data;
            if (Fr == -1)
            {
                Fr = rear;
            }
        }
    }

    char dequeue()
    {
        char data = '\0';
        if (isEmpty())
        {
            cout << "Queue is empty\n";
        }
        else
        {
            data = arr[Fr];
            if (Fr == rear)
            {
                Fr = rear = -1;
            }
            else
            {
                Fr = (Fr + 1) % Qsize;
            }
        }
        return data;
    }

    void removeDuplicates()
    {
        CircularQueue temp(Qsize);
        bool V[256] = {false};
        while (!isEmpty())
        {
            char data = dequeue();
            if (!V[(int)data])
            {
                V[(int)data] = true;
                temp.enqueue(data);
            }
        }
        while (!temp.isEmpty())
        {
            enqueue(temp.dequeue());
        }
    }

    void display()
    {
        if (isEmpty())
        {
            cout << "Queue is empty\n";
        }
        else
        {
            int i = Fr;
            while (i != rear)
            {
                cout << arr[i] << "";
                i = (i + 1) % Qsize;
            }
            cout << arr[rear] << endl;
        }
    }
};



int main()
{
    int QueueSize=100;
    bool c=true;
    int check;
    CircularQueue q(QueueSize);
    cout<<"1.Enqueue\n2.Dequeue\n3.Display\n4.Remove Duplicate\n5.Exit\n\n";
    do
    {
        cout<<"Input option:";
        cin>>check;

        switch(check)
        {
        case 1:
            char value;
            cout<<"Input the value:";
            cin>>value;
            q.enqueue(value);
            break;
        case 2:
            cout<<"Peek value is:"<<q.dequeue()<<endl;
            break;
        case 3:
            q.display();
            break;
        case 4:
            cout << "Before removing duplicates: ";
            q.display();
            q.removeDuplicates();
            cout << "After removing duplicates: ";
            q.display();
            break;
        case 5:
            c=false;
            break;
        }
        cout<<endl;

    }
    while(c);
}
