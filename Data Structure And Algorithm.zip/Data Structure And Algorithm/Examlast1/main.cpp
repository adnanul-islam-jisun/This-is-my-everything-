#include<bits/stdc++.h>
using namespace std;

const int MAX = 100005;
vector<int> adj[MAX];
bool visited[MAX];

void dfs(int v) {
    visited[v] = true;
    for (int u : adj[v]) {
        if (!visited[u]) {
            dfs(u);
        }
    }
}

int main() {
    int n, m;
    cin >> n >> m;
    int start;
    cout<<"Start from:";
    cin >> start;


    for (int i = 0; i < m; i++) {
        int u, v;
        cin >> u >> v;
        adj[u].push_back(v);
    }



    dfs(start);

    cout << "Reachable nodes from node " << start << ":\n";
    for (int i = 1; i <= n; i++) {
        if (visited[i]) {
            cout << i << " ";
        }
    }
    cout << "\n";

    return 0;
}
