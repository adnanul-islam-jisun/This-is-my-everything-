#include<stdio.h>
#include<stdlib.h>
struct ListNode
{
    int value;
    struct ListNode* next;
    struct ListNode* prev;
};

typedef struct ListNode ListNode;
ListNode* head = NULL;
ListNode* tail = NULL;

ListNode* createListNode(int data)
{
    ListNode* temp = (ListNode *)malloc(sizeof(ListNode));
    temp->value = data;
    temp->next = NULL;
    temp->prev = NULL;
    return temp;
}

void printList()
{
    for(ListNode* i=head; i!=NULL; i=i->next)
    {
        printf("%d ", i->value);
    }
    printf("\n");
}

void printListInReverseOrder()
{
    for(ListNode* i=tail; i!=NULL; i=i->prev)
    {
        printf("%d ", i->value);
    }
    printf("\n");
}

void insertLast(int data)
{
    if(head==NULL)
    {
        head = createListNode(data);
        tail = head;
    }
    else
    {
        ListNode* temp = createListNode(data);
        tail->next = temp;
        temp->prev = tail;
        tail = tail->next;  /// or, tail = temp;
        temp = NULL;
    }
}


void insertFirst(int data)
{
    if(head==NULL)
    {
        head = createListNode(data);
        tail = head;
    }
    else
    {
        ListNode* temp = createListNode(data);
        temp->next = head;
        head->prev = temp;
        head = head->prev; /// or, head = temp;
        temp = NULL;
    }
}

ListNode *linearSearch(int data)
{
    for(ListNode *i = head; i!=NULL; i=i->next)
    {
        if(i->value == data) return i;
    }
    return NULL;
}


void insertBefore(int fEle, int data) {
    struct node* ptr = linearSearch(fEle);
    if(ptr == NULL) return;
    struct node* temp = (struct node*)malloc(sizeof(struct node));
    temp->next = NULL;
    temp->prev = NULL;
    temp->value = data;
    temp->prev = ptr->prev;
    ptr->prev->next = temp;
    ptr->prev = temp;
    temp->next = ptr;
    temp = NULL;
    ptr = NULL;
    return;
}



void deleteFirst()
{
    if(head==NULL) return;
    else if(head==tail)
    {
        free(tail);
        head = NULL;
        tail = NULL;
    }
    else
    {
        ListNode* temp = head;
        head = head->next;
        temp->next = NULL;
        head->prev = NULL;
        free(temp);
    }
}

void deleteMiddle(int data)
{
    ListNode* loc = linearSearch(data);
    if(loc==NULL) return;
    loc->prev->next = loc->next;
    loc->next->prev = loc->prev;
    loc->next = NULL;
    loc->prev = NULL;
    free(loc);
    return;
}

void deleteLast()
{
    if(head==NULL) return;
    else if(head==tail)
    {
        free(tail);
        head = NULL;
        tail = NULL;
    }
    else
    {
        ListNode* temp = tail;
        tail = tail->prev;
        tail->next = NULL;
        temp->prev = NULL;
        free(temp);
    }
}

int main()
{

}
