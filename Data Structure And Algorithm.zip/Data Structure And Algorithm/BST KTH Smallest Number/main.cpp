#include<iostream>
using namespace std;

struct Node {
    int data;
    Node* left;
    Node* right;
    Node(int val) {
        data = val;
        left = NULL;
        right = NULL;
    }
};

Node* insert(Node* root, int data) {
    if (root == NULL) {
        root = new Node(data);
        return root;
    }

    if (data < root->data) {
        root->left = insert(root->left, data);
    } else {
        root->right = insert(root->right, data);
    }

    return root;
}

void KthSU(Node* root, int k, int& count, int& kthSmallest) {
    if (root == NULL || count >= k) {
        return;
    }

    KthSU(root->left, k, count, kthSmallest);

    count++;
    if (count == k) {
        kthSmallest = root->data;
        return;
    }

    KthSU(root->right, k, count, kthSmallest);
}

int kthSmallest(Node* root, int k) {
    int count = 0;
    int kthSmallest = -1;

    KthSU(root, k, count, kthSmallest);

    return kthSmallest;
}

int main() {
    Node* root = NULL;

    int n;
    int k;
    cin >> n >>k;

    for (int i = 0; i < n; i++) {
        int data;
        cin >> data;
        root = insert(root, data);
    }


    cout << k << "th smallest element in the tree is: " << kthSmallest(root, k) << endl;

    return 0;
}
