#include <iostream>


using namespace std;


struct node
{
    int data;
    node* next;
};
class Stack
{
private:
    node* top;
public:
    Stack()
    {
        top = NULL;
    }
    bool isEmpty()
    {
        return top == NULL;
    }
    void push(int val)
    {
        node* newnode = new node;
        newnode->data = val;
        newnode->next = top;
        top = newnode;
    }
    int  pop()
    {
        int x;

        if (isEmpty())
        {
            cout << "Stack is empty" << endl;
            return -555;
        }
        node* temp = top;
        top = top->next;
        x=temp->data;

        delete temp;
        return x;

    }
    int peek()
    {
        if (isEmpty())
        {
            cout << "Stack is empty" << endl;
            return -1;
        }
        return top->data;
    }
    void Display()
    {
        if (isEmpty())
        {
            cout << "Stack is empty" << endl;
            return;
        }
        node* temp = top;
        while (temp != NULL)
        {
            cout << temp->data << " ";
            temp = temp->next;
        }
        cout << endl;
    }
    void Sort()
    {
        if (isEmpty())
        {
            cout << "Stack is empty" << endl;
            return;
        }
        Stack temporary;
        while (!isEmpty())
        {
            int temp = pop();

            while (!temporary.isEmpty() && temporary.peek() > temp)
            {
                push(temporary.pop());
            }
            temporary.push(temp);
        }

        while (!temporary.isEmpty())
        {
            push(temporary.pop());

        }
    }
    void reverse()
    {
        if (isEmpty())
        {
            cout << "Stack is empty" << endl;
            return;
        }

        node* prev = NULL;
        node* curr = top;
        node* next_node = NULL;

        while (curr != NULL)
        {
            next_node = curr->next;
            curr->next = prev;
            prev = curr;
            curr = next_node;
        }

        top = prev;
    }
    void clear()
    {
        while (!isEmpty())
        {
            pop();
        }
    }
    int getMin()
    {
        if (isEmpty())
        {
            cout << "Stack is empty" << endl;
            return 0;
        }


        node* curr = top;
        int _min=curr->data;



        while (curr != NULL)
        {
            if(_min>curr->data)
            {
                _min=curr->data;
            }
            curr=curr->next;
        }
        return _min;

    }




};

int main()
{

    Stack s;
    bool x=true;
    int check;
    cout<<"Push press 1\npeek press 2\nPop press 3\nDisplay press 4\nCheck stack is empty or not pree 5\nSort press 6\nExit press 7\n press 8 for reverse\nClear press 9\nMinimum value 10\n";
    while(x)
    {



        cout<<"Input option:";
        cin>>check;
        //cout<<endl;
        switch(check)
        {
        case 1:
            int value;
            cout<<"Input the value:";
            cin>>value;
            s.push(value);
            break;
        case 2:

            cout<<"Peek value is:"<<s.peek()<<endl;
            break;
        case 3:

            int p;
            if( (p=s.pop())!=-555)
            {
                cout<<"POP element is:"<<p<<endl;
            }
            break;
        case 4:
            s.Display();
            break;
        case 5:
            if(s.isEmpty())
            {
                cout<<"Stack is empty."<<endl;
            }
            else
                cout<<"Stack is not empty."<<endl;
            break;
        case 6:
            s.Sort();
            break;
        case 7:
            x=false;
            break;
        case 8:
            s.reverse();
            break;
        case 9:
            s.clear();
            break;
        case 10:
            cout<<"Minimum valu:"<<s.getMin()<<endl;;

        }
        cout<<endl<<endl;
    }

    return 0;
}
