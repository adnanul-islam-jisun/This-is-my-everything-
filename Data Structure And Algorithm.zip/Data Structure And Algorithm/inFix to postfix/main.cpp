#include <iostream>
#include<string>
#define SIZE 100

using namespace std;

char stack[SIZE];
char infix[SIZE];
char postfix[SIZE];
int top=-1;

bool isempty()
{
  if(top==-1)
  return true;
  else
  return false;
}

void push(char value){
    if(top==SIZE-1)
  {    cout<<"Stack is full!\n";
  return;
  }
   else
  {
    top++;
    stack[top]=value;
  }

}
char pop()
{
    int x=stack[top];
 if(isempty()){
  cout<<"Stack is empty!\n";
  exit(1);
 }
 else
  top--;

  return x;
}
int precedence(char c){
    switch(c){
    case '+':
    case '-':
        return 1;
    case '*':
    case '/':
        return 2;
    case '^':
        return 3;
    default:
        return 0;


    }
}





void pofix()
{
    char symbole,next;
    int j=0;

    for(int i=0; i<sizeof(infix)/sizeof(infix[0]); i++)
    {
        symbole=infix[i];
        switch(symbole)
        {
        case '+':
        case '-':
        case '*':
        case '/':
        case '^':
            while(!isempty()&&precedence(stack[top])>=precedence(symbole))
                postfix[j++]=pop();

            push(symbole);
            break;
        case '(':
            push(symbole);
            break;
        case ')':
            while((next=pop())!='(')
                  postfix[j++]=next;
            break;
        default:
            postfix[j++]=symbole;
            break;

        }
    }
    while(!isempty())
        postfix[j++]=pop();

    postfix[j++]='\0';


}






int main()
{
    cout<<"Input the Infix Expression:";
    gets(infix);
    pofix();
     for(int i=0; i<sizeof(postfix)/sizeof(postfix[0]); i++)
    {
        cout<<postfix[i];
    }


    return 0;
}
