#include <iostream>

using namespace std;
 void binarySearch(int array[], int size, int value)
{
    int first = 0,         // First array element
    last = size - 1,       // Last array element
    middle,                // Mid point of search
    position = -1;         // Position of search value
    bool found = false;        // Flag
    int x,y;
    while ( first <= last)
    {
        middle = (first + last) / 2;     // Calculate mid point
        if (array[middle] == value)      // If value is found at mid
    	{
                cout<<"Output:"<<middle;
        }
        else if (array[middle] > value){  // If value is in lower half
            last = middle - 1;
            x=first;
            y=size;

            break;

        }
        else   {
            first = middle + 1;          // If value is in upper half

            x=0;
            y=first-1;
            break;
        }
    }
    cout<<"Output"<<x<<y;

}


int main()
{
    int n;
    cin>>n;
    int arr[n];
    for(int i=0;i<n;i++){
        cin>>arr[i];
    }
    int t;
    cout<<"Target:";
    cin>>t;
    binarySearch(arr,n,t);

   return 0;

}
