import javax.management.remote.SubjectDelegationPermission;

public class Main {

	public static void main(String[] args) {
		hiber h=new hiber();
		h.display();
		Coock C=new Coock();
		C.sing();
		}

}

 class Bird {
	 public static void sing() {
	System.out.println("Pwe pwe pwe");
	 }

}
 class Coock extends Bird{
	 
	 public static void sing(String s) {
	 System.out.println("twe tew");
	 }
	 
}
 class hiber extends Coock{
	 public static void  sing(){
		 System.out.println("Co co co");
	
	 }
	 public  void display() {
		 super.sing();
	 }
 }

