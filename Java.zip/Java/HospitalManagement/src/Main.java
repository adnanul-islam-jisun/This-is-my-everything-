import java.awt.Color;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Main {

	public static void main(String[] args) {
	// Swing
	   JFrame F=new JFrame("Hospital Data Entry");
	   
		F.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		F.setSize(500,500);
		
		JLabel label=new JLabel("Name");
		label.setForeground(Color.blue);
		JTextField textField=new JTextField(15);
		
		JLabel label2=new JLabel("Age:");
		label2.setForeground(Color.blue);
		JTextField textField2=new JTextField(3);
		
		JLabel label3=new JLabel("Gender ");
		label3.setForeground(Color.blue);
		String G[]= { "Male", "Female", "Others" };
		JComboBox comboBox=new JComboBox(G);
		
		JLabel label4= new JLabel("How many day admited");
		label4.setForeground(Color.blue);
		JTextField textField3=new JTextField(3);
		
		
		
		JPanel P=new JPanel();
		P.setBounds(100,100, 700, 50);
		P.add(label);
		P.add(textField);
		P.add(label2);
		P.add(textField2);
		P.add(label3);
		P.add(comboBox);
		F.add(P);
		
		JPanel P1=new JPanel();
		P.setBounds(100,100, 700, 50);
		P.add(label4);
		P.add(textField3);
		//F.add(P1);
		F.setVisible(true);
				
		
		
		
		
		
		
		
		Scanner S=new Scanner(System.in);
		
		System.out.println("1.Reguler\n2.Family Member\n3.Reletive");
		System.out.print("Select One Option:");
		int n=S.nextInt();
		System.out.println();
		System.out.print("How many day Patient stay  in hospital:");
		int day=S.nextInt();
		
		System.out.println("1.General\n2.Cabin\n3.ICU\n4.CCU");
		System.out.print("Select Bed type:");
		int type=S.nextInt();
		System.err.println();
		int ward=1000;
		int ICU= 5000;
		int CCU=4000;
		int cabin=2000;
		
		
		if(n==1) {
			Patient p=new Patient(day);
			if(type==1) {
				System.out.println("Bill:"+p.Ward(ward));
				
			}
			else if (type==2) {
				System.out.println("Bill:"+p.Cabin(cabin));
			}
			else if (type==3) {
				System.out.println("Bill:"+p.ICU(ICU));
			}
			else if (type==4) {
				System.out.println("Bill:"+p.CCU(CCU));
			}
			
			
		}
		else if(n==2) {
			Family p=new Family(day);
			if(type==1) {
				System.out.println("Bill:"+p.Ward(ward));
				
			}
			else if (type==2) {
				System.out.println("Bill:"+p.Cabin(cabin));
			}
			else if (type==3) {
				System.out.println("Bill:"+p.ICU(ICU));
			}
			else if (type==4) {
				System.out.println("Bill:"+p.CCU(CCU));
			}
			
			
		}
		else if(n==3) {
			Relative p=new Relative(day);
			if(type==1) {
				System.out.println("Bill:"+p.Ward(ward));
				
			}
			else if (type==2) {
				System.out.println("Bill:"+p.Cabin(cabin));
			}
			else if (type==3) {
				System.out.println("Bill:"+p.ICU(ICU));
			}
			else if (type==4) {
				System.out.println("Bill:"+p.CCU(CCU));
			}

		}
		
	}

}
