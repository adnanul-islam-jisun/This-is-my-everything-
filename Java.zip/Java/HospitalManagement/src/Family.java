
public class Family extends Hospital {
	int day;
	 public Family(int day) {
		this.day=day;
	}

	@Override
	public int Ward(int charge) {
		int bill=charge*day;
		bill=(int) (bill-bill*0.25);
		return bill;
	}

	@Override
	public int Cabin(int charge) {
		int bill=charge*day;
		bill=(int) (bill-bill*0.25);
		return bill;
	}

	@Override
	public int ICU(int charge) {
		int bill=charge*day;
		bill=(int) (bill-bill*0.25);
		return bill;
	}

	@Override
	public int CCU(int charge) {
		int bill=charge*day;
		bill=(int) (bill-bill*0.25);
		return bill;
	}

}
