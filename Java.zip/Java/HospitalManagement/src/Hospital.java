
public abstract class Hospital {
	public abstract int Ward(int charge);
	public abstract int Cabin(int charge);
	public abstract int ICU(int charge);
	public abstract int CCU(int charge);
}
