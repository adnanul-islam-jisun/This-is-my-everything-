
public class Relative extends Hospital {
	int day;
	 public Relative(int day) {
		 this.day=day;
	}
	 public int Ward(int charge) {
			int bill=charge*day;
			bill=(int) (bill-bill*0.1);
			return bill;
		}

		@Override
		public int Cabin(int charge) {
			int bill=charge*day;
			bill=(int) (bill-bill*0.1);
			return bill;
		}

		@Override
		public int ICU(int charge) {
			int bill=charge*day;
			bill=(int) (bill-bill*0.1);
			return bill;
		}

		@Override
		public int CCU(int charge) {
			int bill=charge*day;
			bill=(int) (bill-bill*0.1);
			return bill;
		}
	 

}
