
public class Patient extends Hospital {
	int day;
	
	public Patient(int day ) {
		this.day=day;
	}

	@Override
	public int Ward(int charge) {
		int bill=day*charge;
		return bill;
	}

	@Override
	public int Cabin(int charge) {
		int bill=day*charge;
		return bill;
	}

	@Override
	public int ICU(int charge) {
		int bill=day*charge;
		return bill;
	}

	@Override
	public int CCU(int charge) {
		int bill=day*charge;
		return bill;
	}

	
}
