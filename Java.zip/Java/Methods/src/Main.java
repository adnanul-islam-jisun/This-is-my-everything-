
public class Main {

	public static void main(String[] args) {
		Circle C=new Circle(12, 8, 5);
		System.out.println("Area of the circul:"+C.Area());
		
		C.PointInsidCircle(10, 6);
		C.CircleInsideCircle(14, 12, 5);
		System.out.println("Leng the Of Tangent:"+C.LengthOfTangent(25,17));
		//C.CircleInsideCircle(9,3, 1);
	}

}
