
public class Circle extends Point {
	
	public Circle(int x, int y, double r) {
		super(x, y, r);
		
	}
	public  double Area() {
		return Math.PI*r*r;
	}
	public  void  PointInsidCircle(int x,int y) {
		 if ((super.x - x) * (super.x - x) +
		            (super.y - y) * (super.y - y) <= r * r)
		            System.out.println("Insid"); 
		 else
		        	System.out.println("Not Insid");
	}
	public double LengthOfTangent(int x,int y) {
		double px=Math.pow((super.x-x), 2);
		double py=Math.pow((super.y-y),2);
		double a=Math.sqrt(px+py);
		return Math.sqrt(Math.pow(a,2)-Math.pow(r, 2));
	}
	public void CircleInsideCircle(int x,int y,double r) {
		double px=Math.pow((super.x-x), 2);
		double py=Math.pow((super.y-y),2);
		double a=Math.sqrt(px+py);
	if(super.r<=r) {	
		 if (a + super.r <= r)
	        {
	            System.out.println("The smaller circle lies completely") ;
	        }         
	        else
	        {
	            System.out.println("The smaller circle does not lies inside"
	                + " the bigger circle completely.") ;
	        }
		}
	else  {
		if (a + r <= super.r)
        {
            System.out.println("The smaller circle lies completely") ;
        }         
        else
        {
            System.out.println("The smaller circle does not lies inside"
                + " the bigger circle completely.") ;
        }
		
	}
	}
	
}
