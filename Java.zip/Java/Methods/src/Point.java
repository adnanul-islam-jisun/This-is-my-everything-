
public class Point {
	int x;
	int y;
	double r;
	public Point(int x,int y,double r) {
		this.x=x;
		this.y=y;
		this.r=r;
	}
}
