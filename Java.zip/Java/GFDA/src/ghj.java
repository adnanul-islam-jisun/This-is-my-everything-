import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.StringTokenizer;

public class ghj {
	public static void main(String[] args) throws IOException {
		FileReader file= new FileReader("C:\\Users\\adnan\\OneDrive\\Desktop\\AnnualSell.txt");
		BufferedReader F = new BufferedReader(file);
		String st =F.readLine();
		double  invest=0;
		double sell=0;
		
		while ((st=F.readLine())!=null) {
			StringTokenizer T =new StringTokenizer(st);
//			String Book=T.nextToken();
//			double up=Double.parseDouble(T.nextToken());
//			double sp=Double.parseDouble(T.nextToken());;
//			double tus=Double.parseDouble(T.nextToken());
//			invest+=up;
//			sell+=sp;			
		}
		System.out.println(invest+" "+sell);
		F.close();
	}
}
