import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.StringTokenizer;

public class Main {

	
		public static void main(String[] args)  {
			
			try {
				FileReader 	file = new FileReader("C:\\Users\\adnan\\OneDrive\\Desktop\\AnnualSell.txt");
			
			BufferedReader F = new BufferedReader(file);
//			FileWriter W= new FileWriter("C:\\Users\\adnan\\OneDrive\\Desktop\\New.txt");
//			BufferedWriter w= new BufferedWriter(W);
			String st;
			try {
				st = F.readLine();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			try {
				while ((st=F.readLine())!=null) {
					StringTokenizer T= new StringTokenizer(st);
					int n=st.split("").length;
					String[] arr=new String[n];
					for (int i = 0; i < arr.length; i++) {
						String S=T.nextToken();
						arr[i]=S;
					}
					Collections.reverse(Arrays.asList(arr));
//				for (int i = 0; i < arr.length; i++) {
//					w.write(arr[i]);
//				}
					
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				file.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		

	
		
}

}
