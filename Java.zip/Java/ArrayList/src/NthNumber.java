import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class NthNumber {

	public static void main(String[] args) {
		Scanner in=new Scanner(System.in);
		System.out.print("Input the Number:");
		int n=in.nextInt();
		//int n=123;
		System.out.print("Input the position of the number:");
		int p=in.nextInt();
		List<Integer> l = new ArrayList<Integer>();
		while(n>=1) {
		int r=n%10;
		n=n/10;
		l.add(r);
		}
		//System.out.println(l.size());
		int x=l.size()-p;
		if(x<0)
			x=x*(-1);
		//System.out.println(x);

		System.out.println(l.get(x));

	}

}
