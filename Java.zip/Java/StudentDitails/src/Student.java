import java.util.Scanner;

public class Student {
	protected String name;
	protected int ID;
	
	Scanner I=new Scanner(System.in);
	public void get() {
		System.out.print("Student Name:");
		name=I.nextLine();
		System.out.println();
		ID=I.nextInt();	
	}	

}
