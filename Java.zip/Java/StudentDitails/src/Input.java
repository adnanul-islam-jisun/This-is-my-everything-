import java.util.Scanner;

public class Input extends Student {

	float[] ma=new float[3];
	Scanner x=new Scanner(System.in);
	protected void marks() {
		for(int i=0;i<3;i++) {
			System.out.print(i+"subject Number");
			ma[i]=x.nextFloat();
			System.out.println();
		}

	}
	

}
