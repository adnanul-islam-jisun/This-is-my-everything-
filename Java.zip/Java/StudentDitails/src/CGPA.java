
public class CGPA extends Student {

	protected CGPA(String name, int ID) {
		super(name, ID);
	}
	
}
