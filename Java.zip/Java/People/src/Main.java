
public class Main {

	public static void main(String[] args) {
		Human adn=new Human("Adnan", 22, 32, true);
		Human ratHuman=new Human("Fatta", 32, 52, false);
		System.out.println("Name:"+adn.Name);
		System.out.println("Age:"+adn.age);

	}

}
