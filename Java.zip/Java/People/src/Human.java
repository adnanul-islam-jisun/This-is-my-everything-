
public class Human {
	String Name;
	int age;
	float hight;
	boolean marrid;

	public Human(String Name,int age,float hight,boolean marrid) {
		this.age=age;
		this.Name=Name;
		this.hight=hight;
		this.marrid=marrid;
	}
}
