
public class Ans {
	public static void main(String[] args) {
		Complex a=new Complex(12,3);
		Complex b=new Complex(12, 10);
		System.out.println("Area"+a.area());
		System.out.println("Sum"+a.Rec());
		System.out.println("Area"+b.area());
		System.out.println(b.Rec());
	}

}
class Complex{
	int real;
	int ima;
	public Complex(int r,int i){
		real=r;
		ima=i;
		
	}
	public  double  area() {
		return 1;
		
	}
	public int Rec(){
	return real+ima;	
	}
	
}
