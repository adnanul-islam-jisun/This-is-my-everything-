public class A{
	int red;
	int hig;
 
	 A(int r,int h) {
		this.red=r;
		this.hig=h;
	}
	
	 
	 public static double Area(int red) {
		 return Math.PI*red*red;
	 }
	 public static double Cyl(int h,double a) {
		 return h*a;
		 
	 }
	 public static void print(double p) {
		 System.out.println(p);
	 }
	
}