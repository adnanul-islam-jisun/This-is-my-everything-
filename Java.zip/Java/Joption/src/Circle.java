import java.awt.geom.Area;
import java.awt.print.Printable;
import java.util.Scanner;

public class Circle {

	public static void main(String[] args) {
		Scanner sc=new  Scanner(System.in);
		
		int x=sc.nextInt();
		int h=sc.nextInt();
		A p=new A(x,h);
		double y=p.Area(p.hig);
		double z=p.Cyl(p.hig,y);
		p.print(z);

	}
	
}

