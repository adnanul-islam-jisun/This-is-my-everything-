import java.util.Scanner;

public class Input {

	public static void main(String[] args) {
		Scanner m =new Scanner(System.in);
		System.out.println(z);
		int z=m.nextInt();
		
	}

}
