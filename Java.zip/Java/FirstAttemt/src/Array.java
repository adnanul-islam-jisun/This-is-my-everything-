
public class Array {

	public static void main(String[] args) {
		System.out.println("out the");
	}
	public void Alu() {
			
	}

	}


