import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.StringTokenizer;

public class Hello
{
	public static void main(String[] args) throws IOException {
		FileReader file= new FileReader("C:\\Users\\adnan\\OneDrive\\Desktop\\AnnualSell.txt");
		BufferedReader F = new BufferedReader(file);
		String st =F.readLine();
		double  invest=0;
		double sell=0;
		
		while ((st=F.readLine())!=null) {
			StringTokenizer T =new StringTokenizer(st);
	
		}
		System.out.println(invest+" "+sell);
		F.close();
	}
}
