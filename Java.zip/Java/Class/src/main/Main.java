//import java.util.Scanner;
package main;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		
		/*Scanner s=new Scanner(System.in);
		int[] arr=new int[10];
		for(int i=0;i<10;i++) {
			arr[i]=s.nextInt();
		}
		System.out.print("Search Number:");
		int x=s.nextInt();
		
		System.out.println("Max:"+p.max(arr));
		System.out.println("Min:"+p.min(arr));
		p.search(arr, x);
		*/
//		Practice[] p=new Practice[5];
//		for(int i=0;i<5;i++) {
//			
//			p[i]=new Practice(); 
//			p[i].run();
//		}
//		int n=3;
//		int[] a=new int[n];
//		a[0]=9;
//		a[1]=7;
//		a[2]=4;
//		
//		//Arrays.sort(a);
//	int x=10;
//	int b=12;
//	System.err.println("A B"+(x+b)+x);
		
//		for(int i=0;i<n;i++) {
//			for(int j=i+1;j<n;j++) {
//				if(a[i]>a[j]) {
//					int x=a[i];
//					a[i]=a[j];
//					a[j]=x;	
//				}
//			}
//		}
//		for (int fgh: a) {
//            System.out.println(fgh);
//            
		//System.out.println(Arrays.toString(a));
//        }
//		for(int i=0;i<n;i++) {
//			System.out.println("");
//		}
		Scanner scanner=new Scanner(System.in);
		 char[] a = new char[];
		
		for(int i=0;i<;i++) {
			char x=a[i];
			a[i]=a[s-1-i];
			a[s-1-i]=x;
		
		}
		for(int i=0;i<a.length;i++) {
			System.out.println(a[i]);
		}
	
	}
}
  
   
