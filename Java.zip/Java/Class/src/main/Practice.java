package main;

public class Practice{
//	public void run() {
//		System.out.println("Car can run");
//	}

	/*
	public int max(int arr[]) {
		int max=arr[0];
		for(int i=0;i<10;i++) {
			if(max<arr[i]) {
				max=arr[i];
			}		
		}
		return max;	
	}
	public int min(int arr[]) {
		int min=arr[0];
		
		for(int i=0;i<10;i++) {
			if (arr[i]<min) {
				min=arr[i];
			}
		}
		return min;	
	}
	public void search(int arr[],int x) {
		int flag=0;
		
		for(int i=0;i<10;i++) {
			if(arr[i]==x) {
				flag=1;
				break;
			}	
		}
		if (flag==1) {
			System.out.println("Yes");
		}
		else 
			System.out.println("No");	
	}
}
*/


	
}





