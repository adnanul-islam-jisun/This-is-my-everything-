/**
 * 
 */
/**
 * @author adnan
 *
 */
module problem1 {
}