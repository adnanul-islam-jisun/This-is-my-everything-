
public class Tiger extends Animal implements Movable {

	@Override
	public String foodEnergySourcing() {
		
		return null;
	}

	@Override
	public boolean canMove() {
		
		return true;
	}

	@Override
	public boolean canFly() {	
		return false;
	}
	@Override
	public boolean canSwing() {
		return false;
	}

}
