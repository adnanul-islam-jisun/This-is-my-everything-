
public class Hilsha extends Animal implements Movable {

	@Override
	public boolean canMove() {
		
		return true;
	}

	@Override
	public boolean canFly() {
		
		return false;
	}

	@Override
	public boolean canSwing() {
		
		return true;
	}

	@Override
	public String foodEnergySourcing() {
		return null;
	}

}
