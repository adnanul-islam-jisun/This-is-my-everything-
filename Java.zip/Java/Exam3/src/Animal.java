
public abstract class Animal {
	public abstract String foodEnergySourcing();

}
