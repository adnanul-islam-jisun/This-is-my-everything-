
public interface Movable {
	public boolean canMove();
	public boolean canFly();
	public boolean canSwing();
	

}
