import java.util.Scanner;

import javax.swing.plaf.basic.BasicInternalFrameTitlePane.MoveAction;

public class MyClass {
	public static void main(String args[]) {
		Animal a;
		Scanner sc = new Scanner(System.in);
		String animlName= sc.next();	
		a=new Tiger();
		System.out.println("Animal Name:"+animlName);
		System.out.println("Food:"+((Movable)a).canMove());
	}

}
