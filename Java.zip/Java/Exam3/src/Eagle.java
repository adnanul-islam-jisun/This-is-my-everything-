
public class Eagle extends Animal implements Movable {

	@Override
	public boolean canMove() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean canFly() {
		
		return true;
	}

	@Override
	public boolean canSwing() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String foodEnergySourcing() {
		// TODO Auto-generated method stub
		return null;
	}

}
