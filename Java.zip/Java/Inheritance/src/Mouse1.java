
public class Mouse1 extends Mouse {

	 void blutooth() {
		System.out.println("Blutooth");
		System.out.println("Blutooth");
		System.out.println("Blutooth");
		System.out.println("Blutooth");
		System.out.println("Blutooth");
		System.out.println("Blutooth");
		
	}
}
