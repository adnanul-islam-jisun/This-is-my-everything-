
public class Mouse2 extends Mouse{
	 void RGB() {
		System.out.println("Speacial for me");
		
		
	}

}
