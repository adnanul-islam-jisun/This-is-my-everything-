
public class Mouse {
	public static void rightClic() {
		System.out.println("Right Click");
		
	}
	public static void leftClick() {
		System.out.println("Left Click");
	}
	public static void Scroll() {
		System.out.println("Scroling");
		
	}

}
