
public class Main {

	public static void main(String[] args) {
		/**
		 * mouse create 
		 * which has multiple Input and i use Inheritance for it 
		 */
		Mouse1 m1=new Mouse1();
		Mouse2 m2=new Mouse2();
		m1.blutooth();
		m1.leftClick();
		m2.RGB();
		m2.Scroll();
	}

}
